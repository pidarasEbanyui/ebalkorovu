@echo off
cd /d "%~dp0"

net session >nul 2>&1
if %errorlevel%==0 (
    start "" "InteriumInjector.exe"
    exit
)

powershell -Command ^
"try { Start-Process '%~dp0InteriumInjector.exe' -Verb RunAs -ErrorAction Stop } catch { Start-Process '%~dp0InteriumInjector.exe' }" >nul 2>&1

exit